﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEditor;

public class SimpleGizmos : MonoBehaviour
{
    public Color gizmoColor;
    public Color gizmoWireColor;
    public Color gizmoSelectedColor;
    public int columns = 1;
    public int rows = 1;
    public int cellSize;

    /// <summary>
    /// draws gizmos in the scene
    /// </summary>
    private void OnDrawGizmos()
    {
        for (int i = 0; i < rows + 1; i++)
        {
            Gizmos.DrawLine(
                new Vector3(0, i * cellSize, transform.position.z),
                new Vector3(columns * cellSize, i * cellSize, transform.position.z));
            for (int j = 0; j < columns + 1; j++)
            {
                Gizmos.DrawLine(
                    new Vector3(j * cellSize, 0, transform.position.z),
                    new Vector3(j * cellSize, rows * cellSize, transform.position.z));
            }
        }
    }
}
